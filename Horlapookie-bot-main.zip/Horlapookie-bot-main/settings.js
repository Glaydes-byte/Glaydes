export default {
  // OpenAI API configuration
  openaiApiKey: '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',

  // Giphy API configuration
  giphyApiKey: '',
  // Gemini API configuration
  geminiApiKey: '',
  // Imgur API configuration
  imgurClientId: '',
  // Copilot API configuration
  copilotApiKey: '',
  // Football API configuration
  FOOTBALL_API_KEY: '',

  // Mega.nz credentials for auth storage
  megaEmail: 'olamilekanidowu998@gmail.com',
  megaPassword: 'Omotoyosi',
};